import { useState } from 'react';
import reactLogo from './assets/react.svg';
import viteLogo from '/vite.svg';
import './App.css';

function App() {
  const [count, setCount] = useState(0);

  return (
    <>
      <ul>
        <li>
          <input type="checkbox" />
          Hello
        </li>
        <li>
          <input type="checkbox" />
          <s> Hello </s>
          <button>X</button>
        </li>
      </ul>

      <input />
      <button> Add </button>
    </>
  );
}

export default App;
